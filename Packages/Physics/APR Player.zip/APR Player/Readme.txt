APR Player

- Import the package into a new project, Unity version 2019 or 2020.
- Inject the project settings from the toolbar (APR Player --> APR Player Settings Injector)
- Play the example scenes
- Create & have fun.